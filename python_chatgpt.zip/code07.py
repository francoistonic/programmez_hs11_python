def propositionIA(pos):
    return random.choice(pos)
