#!/usr/bin/env python
# coding: utf-8

import cgi

print("Content-type: text/html; charset=utf-8\n")

html = """<!DOCTYPE html>
<head>
    <title>Ma première page CGI</title>
</head>
<body>
	<h1>Ma première page CGI</h1>
	<p>Ceci est une page de test</p>
</body>
</html>
"""

print(html)
