#!/usr/bin/env python
# coding: utf-8

import cgi

#Préparation des éléments à envoyer
declaration="""Content-type: text/html; charset=utf-8\n<!DOCTYPE html>\n"""
head="""
<head>
    <title>Mon programme</title>
</head>"""
formulaire="""
    <h2>Remplissez ce formulaire</h2>
    <form action="/page2.py" method="post">
	Saisissez votre nom : <br/>
        <input type="text" name="nom" value="Votre nom" /><br/>
        Saisissez votre prénom : <br/>
        <input type="text" name="prenom" value="Votre prénom" /><br/>
        <input type="submit" name="envoyer" value="Envoyer">
    </form>
"""
#envoi du début du document html
print(declaration)
print('<html>')
print(head)
print('<body>')

#récupération des données du formulaire
form = cgi.FieldStorage()
if form.getvalue("envoyer")=='Envoyer':
	print('<h2>Bienvenue</h2>')
	print('<h3>Bonjour ')
	print(form.getvalue("prenom")+' '+form.getvalue("nom"))
else:
	print(formulaire)
print('</body>')
print('</html>')

