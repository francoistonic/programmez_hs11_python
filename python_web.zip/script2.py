# -*- coding utf-8 -*-
import requests
from bs4 import BeautifulSoup as bs
import re
#intialisation de la session
sess=requests.session()
sess.get('https://uphf.fr/annuaire')
#lecture des noms à rechercher
file=open('liste_noms.txt','r')
nom=file.readline()
#Boucle tant que un nom est lu
while nom:
	#preparation des donnees pour envoi
        recherche={'name':nom,'service':'','form_build_id':'','form_id':'ldap_directory_listing','op':'Rechercher'}
	#envoi des donnees 
        r=sess.post('https://uphf.fr/annuaire',data=recherche)
	#recuperation du contenu du retour
        htmltext=r.text
	#recherche du nom, premon et telephone
        if 'h2' in htmltext:
                soup=bs(htmltext,'html.parser')
                s=soup.find_all('h2')[0]
                s=str(s)
                nomprenom=re.search(r'<span>(.*)</span>',s).group(1)
                nomprenom=nomprenom.split('<br/>')
                print(nomprenom)
                t=soup.find_all('a')
                for link in t:
                        l=link.get('href')
                        if 'tel:+' in l:
                                print(l)
                nom=file.readline()
file.close()
