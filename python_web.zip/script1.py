# -*- coding utf-8 -*-
import requests
from bs4 import BeautifulSoup as bs
import re

rep=requests.get('https://uphf.fr')
soup = bs(rep.text,'html.parser')
for link in soup.find_all('a'):
	print(link.get('href'))

