Implémentation d'un worker python pour scenario, dans le cadre de l'article
pour le numéro spécial python de _Programmez_.
