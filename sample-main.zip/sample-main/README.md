Just a place to store sample files, for use in testing access to a GitHub repo.
